# Starlink explainer — Remotion project

    npm install
    npx remotion studio
    npx remotion render src/index.ts Main out/video.mp4

- Composition ID: `Main` (1920×1080, 30fps, length derived from the SRT)
- Optional voiceover: put `voiceover.mp3` in `public/` (plays in Studio preview; set `VO_IN_RENDER = true` in `src/config.ts` to bake it into renders)
- All colours/easings/springs/fonts: `src/theme.ts`. All timing comes from `src/data/script.srt`.
- SFX: `public/sfx/*.wav` (regenerate: `npm run sfx`)
