// Project-wide switches. Everything time-related derives from FPS.
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

// Voiceover (public/voiceover.mp3) — optional, only used if the file exists.
export const VO_IN_PREVIEW = true; // plays inside Remotion Studio
export const VO_IN_RENDER = false; // off in rendered MP4 by default (set true to bake it in)

// Sound effects (public/sfx/*.wav)
export const SFX_ENABLED = true;
