import React from "react";
import {interpolate} from "remotion";
import {Earth} from "../components/Earth";
import {Check} from "../components/Icons";
import {Entrance, useProgress, useSpring} from "../components/Motion";
import {Orbit} from "../components/Orbit";
import {Sfx} from "../components/Sfx";
import {WordReveal} from "../components/Text";
import {useT} from "../components/useT";
import {alpha, theme} from "../theme";

/** Scene 6 — Statement / ending. Cue 6: "online যাওয়া সম্ভব হয়।" Short (~1.7s): lands fast, then holds. */
export const S6Online: React.FC = () => {
  const {frame, s} = useT();
  const badge = useSpring(s(0.1), theme.spring.bouncy);
  const ring = useProgress(s(0.15), 0.9);
  return (
    <>
      <Earth delay={0} rise={210} />
      <Orbit cy={480} opacity={0.55} seconds={12} start={3.6} />

      <div style={{position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", rowGap: 20, paddingBottom: 40}}>
        <div style={{display: "flex", alignItems: "center", columnGap: 56}}>
          {/* check badge with ripple */}
          <div style={{position: "relative", width: 190, height: 190}}>
            {[0, 1].map((i) => {
              const p = Math.max(0, Math.min(1, ring * 1.2 - i * 0.25));
              return (
                <div
                  key={i}
                  style={{
                    position: "absolute",
                    inset: 0,
                    borderRadius: "50%",
                    border: `3px solid ${alpha(theme.colors.accent, 0.7 * (1 - p))}`,
                    transform: `scale(${1 + p * 0.9})`,
                  }}
                />
              );
            })}
            <div
              style={{
                position: "absolute",
                inset: 0,
                borderRadius: "50%",
                background: theme.colors.primary,
                boxShadow: `0 0 70px ${alpha(theme.colors.primary, 0.65)}, inset 0 3px 0 ${alpha(theme.colors.text, 0.4)}`,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                opacity: Math.min(1, badge * 1.6),
                transform: `scale(${interpolate(badge, [0, 1], [0.3, 1]) + Math.sin(frame / 18) * 0.01})`,
              }}
            >
              <Check size={118} color={theme.colors.text} stroke={24} />
            </div>
          </div>
          <Entrance delay={s(0.03)} y={50} from={1.15} blur={12} cfg={theme.spring.bouncy}>
            <div
              style={{
                fontFamily: theme.fonts.display,
                fontWeight: theme.weights.hero,
                fontSize: 250,
                lineHeight: 1.15,
                letterSpacing: 0,
                background: `linear-gradient(95deg, ${theme.colors.text} 0%, ${theme.colors.accent} 100%)`,
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                WebkitTextFillColor: "transparent",
                padding: "0 0.05em 0.1em",
              }}
            >
              online
            </div>
          </Entrance>
        </div>
        <WordReveal words={["যাওয়া", "সম্ভব", "হয়"]} size={108} weight={theme.weights.strong} delay={s(0.3)} per={s(0.1)} gap={32} />
      </div>

      <Sfx name="chime" at={s(0.05)} />
    </>
  );
};
