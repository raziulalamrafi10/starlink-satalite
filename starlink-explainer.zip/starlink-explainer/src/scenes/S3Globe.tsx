import React from "react";
import {interpolate} from "remotion";
import {Entrance, Float, useProgress} from "../components/Motion";
import {ServerRack, Pin} from "../components/Icons";
import {Sfx} from "../components/Sfx";
import {Chip, WordReveal} from "../components/Text";
import {useT} from "../components/useT";
import {lineStart, spread, wordStart} from "../timing";
import {alpha, theme} from "../theme";

const CX = 960;
const CY = 565;
const R = 255;

// pin offsets from globe centre
const PINS: {x: number; y: number}[] = [
  {x: -170, y: -70}, // 0  server (labelled)
  {x: 160, y: -10}, // 1  data center (labelled)
  {x: -70, y: 120},
  {x: 85, y: 150},
  {x: 20, y: -165},
  {x: -205, y: 80},
  {x: 205, y: 105},
];
const EDGES: [number, number][] = [
  [0, 4],
  [4, 1],
  [1, 6],
  [6, 3],
  [3, 2],
  [2, 5],
  [5, 0],
  [0, 2],
  [4, 3],
  [1, 3],
];

const Globe: React.FC = () => {
  const {frame, fps} = useT();
  const rot = (frame / fps) * 0.45;
  const lat = [-0.62, -0.3, 0, 0.3, 0.62];
  return (
    <svg width={R * 2 + 120} height={R * 2 + 120} viewBox={`${-R - 60} ${-R - 60} ${R * 2 + 120} ${R * 2 + 120}`} style={{overflow: "visible"}}>
      <defs>
        <radialGradient id="globeFill" cx="0.35" cy="0.3" r="0.9">
          <stop offset="0" stopColor={alpha(theme.colors.primary, 0.5)} />
          <stop offset="0.55" stopColor={alpha(theme.colors.bgAlt, 0.95)} />
          <stop offset="1" stopColor={theme.colors.bg} />
        </radialGradient>
        <clipPath id="globeClip">
          <circle r={R} />
        </clipPath>
      </defs>
      <circle r={R + 26} fill="none" stroke={alpha(theme.colors.accent, 0.22)} strokeWidth={2} />
      <circle r={R} fill="url(#globeFill)" stroke={alpha(theme.colors.accent, 0.75)} strokeWidth={3.5} style={{filter: `drop-shadow(0 0 40px ${alpha(theme.colors.primary, 0.5)})`}} />
      <g clipPath="url(#globeClip)" fill="none" stroke={alpha(theme.colors.text, 0.2)} strokeWidth={1.8}>
        {Array.from({length: 6}).map((_, k) => {
          const th = rot + (k * Math.PI) / 6;
          return <ellipse key={k} rx={Math.abs(Math.cos(th)) * R} ry={R} />;
        })}
        {lat.map((l, i) => {
          const y = l * R;
          const w = Math.sqrt(R * R - y * y);
          return <ellipse key={i} cx={0} cy={y} rx={w} ry={w * 0.13} />;
        })}
      </g>
    </svg>
  );
};

const Edge: React.FC<{a: number; b: number; delay: number}> = ({a, b, delay}) => {
  const {frame, fps, s} = useT();
  const p = interpolate(frame, [delay, delay + s(0.5)], [0, 1], {easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  const A = PINS[a];
  const B = PINS[b];
  const len = Math.hypot(B.x - A.x, B.y - A.y);
  const t = ((frame - delay - s(0.5)) / (fps * 1.8) + a * 0.13) % 1;
  const show = frame > delay + s(0.5);
  const tt = (t + 1) % 1;
  return (
    <g>
      <line
        x1={CX + A.x}
        y1={CY + A.y}
        x2={CX + B.x}
        y2={CY + B.y}
        stroke={alpha(theme.colors.accent, 0.8)}
        strokeWidth={3}
        strokeLinecap="round"
        strokeDasharray={len}
        strokeDashoffset={len * (1 - p)}
      />
      {show && (
        <circle cx={CX + A.x + (B.x - A.x) * tt} cy={CY + A.y + (B.y - A.y) * tt} r={6} fill={theme.colors.text} style={{filter: `drop-shadow(0 0 10px ${theme.colors.accent})`}} />
      )}
    </g>
  );
};

/** Scene 3 — Hub & Spoke / globe. Cue 3: servers & data centers around Earth, then Starlink connects the network. */
export const S3Globe: React.FC = () => {
  const {frame, s} = useT();
  const phaseB = lineStart(3, 1);
  const serverAt = spread(3, 2, 0);
  const dcAt = spread(3, 2, 1);
  const capAt = wordStart(3, "হলো") + s(0.1);

  const aExit = interpolate(frame, [phaseB - s(0.3), phaseB], [0, 1], {easing: theme.ease.in, extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  const globeIn = useProgress(0, 0.8);

  return (
    <>
      {/* globe */}
      <div
        style={{
          position: "absolute",
          left: CX - (R + 60),
          top: CY - (R + 60),
          opacity: globeIn,
          transform: `scale(${interpolate(globeIn, [0, 1], [0.82, 1])})`,
        }}
      >
        <Float amp={5} period={46}>
          <Globe />
        </Float>
      </div>

      {/* network mesh (phase B) */}
      <svg width={1920} height={1080} style={{position: "absolute", inset: 0, overflow: "visible"}}>
        {frame >= phaseB && EDGES.map(([a, b], i) => <Edge key={i} a={a} b={b} delay={phaseB + s(0.15) + i * s(0.1)} />)}
        {/* connectors from labelled pins to chips */}
        <line x1={CX + PINS[0].x} y1={CY + PINS[0].y} x2={CX - 480} y2={CY - 150} stroke={alpha(theme.colors.text, 0.35)} strokeWidth={2} strokeDasharray="6 8" opacity={frame > serverAt + s(0.2) ? 1 : 0} />
        <line x1={CX + PINS[1].x} y1={CY + PINS[1].y} x2={CX + 480} y2={CY - 70} stroke={alpha(theme.colors.text, 0.35)} strokeWidth={2} strokeDasharray="6 8" opacity={frame > dcAt + s(0.2) ? 1 : 0} />
      </svg>

      {/* pins */}
      {PINS.map((p, i) => {
        const d = i === 0 ? serverAt : i === 1 ? dcAt : s(0.2) + (i - 2) * s(0.12) + (i > 1 ? s(0.15) : 0);
        const pulse = ((frame / 38 + i * 0.21) % 1);
        return (
          <div key={i} style={{position: "absolute", left: CX + p.x - 13, top: CY + p.y - 13}}>
            <Entrance delay={d} y={-26} from={0.2} cfg={theme.spring.bouncy}>
              <Pin size={26} pulse={pulse} color={i < 2 ? theme.colors.text : theme.colors.accent} />
            </Entrance>
          </div>
        );
      })}

      {/* labels */}
      <div style={{position: "absolute", left: CX - 480 - 262, top: CY - 150 - 45}}>
        <Entrance delay={serverAt + s(0.08)} x={-40} y={10}>
          <Chip size={46} tone="accent" icon={<ServerRack size={60} />}>server</Chip>
        </Entrance>
      </div>
      <div style={{position: "absolute", left: CX + 480, top: CY - 70 - 45}}>
        <Entrance delay={dcAt + s(0.08)} x={40} y={10}>
          <Chip size={46} tone="accent" icon={<ServerRack size={60} />}>data center</Chip>
        </Entrance>
      </div>

      {/* headline A */}
      {frame < phaseB + 3 && (
        <div style={{position: "absolute", left: 0, right: 0, top: 92, display: "flex", justifyContent: "center", opacity: 1 - aExit, transform: `translateY(${-30 * aExit}px)`, filter: `blur(${aExit * 6}px)`}}>
          <WordReveal words={["পৃথিবীর", "বিভিন্ন"]} size={100} delay={s(0.1)} per={s(0.12)} gap={34} />
        </div>
      )}
      {/* headline B */}
      {frame >= phaseB && (
        <div style={{position: "absolute", left: 0, right: 0, top: 92, display: "flex", justifyContent: "center"}}>
          <WordReveal words={[{t: "Starlink", kind: "grad"}, "এর", "কাজ"]} size={108} delay={phaseB} per={s(0.1)} gap={34} />
        </div>
      )}

      {/* caption B — continues into the next scene ("...network") */}
      <div style={{position: "absolute", left: 0, right: 0, top: 905, display: "flex", justifyContent: "center"}}>
        {frame >= capAt - 1 && <WordReveal words={["পৃথিবীর", "সেই", {t: "internet", kind: "accent"}]} size={78} weight={theme.weights.strong} delay={capAt} per={s(0.1)} gap={28} />}
      </div>

      <Sfx name="pop" at={serverAt} />
      <Sfx name="pop" at={dcAt} rate={1.1} vol={0.9} />
      <Sfx name="whoosh-soft" at={phaseB} />
    </>
  );
};
