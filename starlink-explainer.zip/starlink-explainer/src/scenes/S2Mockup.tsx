import React from "react";
import {interpolate} from "remotion";
import {Float, Entrance, useProgress, useSpring} from "../components/Motion";
import {Glass} from "../components/Glass";
import {Play, SearchIcon} from "../components/Icons";
import {Sfx} from "../components/Sfx";
import {Chip, WordReveal} from "../components/Text";
import {useT} from "../components/useT";
import {spread, wordStart} from "../timing";
import {alpha, theme} from "../theme";

const CARD_W = 700;
const CARD_H = 430;

const WindowBar: React.FC<{label: string}> = ({label}) => (
  <div style={{height: 64, display: "flex", alignItems: "center", padding: "0 26px", gap: 12, borderBottom: `1.5px solid ${alpha(theme.colors.text, 0.1)}`}}>
    {[0, 1, 2].map((i) => (
      <div key={i} style={{width: 14, height: 14, borderRadius: "50%", background: alpha(theme.colors.text, 0.28)}} />
    ))}
    <div style={{marginLeft: 16, fontFamily: theme.fonts.body, fontWeight: theme.weights.strong, fontSize: 30, color: theme.colors.textDim, letterSpacing: 0}}>{label}</div>
  </div>
);

/** YouTube-style video window (generic play UI, no brand mark). */
const VideoCard: React.FC<{delay: number}> = ({delay}) => {
  const {frame, s} = useT();
  const prog = useProgress(delay + s(0.4), 3.2, theme.ease.inOut);
  const pulse = 1 + Math.sin(frame / 12) * 0.03;
  return (
    <Glass w={CARD_W} h={CARD_H} glow>
      <WindowBar label="YouTube" />
      <div style={{position: "absolute", left: 30, right: 30, top: 92, bottom: 92, borderRadius: 20, overflow: "hidden", background: `linear-gradient(135deg, ${alpha(theme.colors.primary, 0.35)}, ${alpha(theme.colors.accent, 0.18)} 60%, ${alpha(theme.colors.bgAlt, 0.9)})`}}>
        {[0, 1, 2].map((i) => (
          <div
            key={i}
            style={{
              position: "absolute",
              left: -80,
              right: -80,
              top: 40 + i * 52 + Math.sin(frame / 26 + i) * 8,
              height: 3,
              borderRadius: 4,
              background: alpha(theme.colors.text, 0.12 + i * 0.04),
              transform: `rotate(${-6 + i * 2}deg)`,
            }}
          />
        ))}
        <div
          style={{
            position: "absolute",
            left: "50%",
            top: "50%",
            width: 124,
            height: 124,
            marginLeft: -62,
            marginTop: -62,
            borderRadius: "50%",
            background: theme.colors.primary,
            boxShadow: `0 0 60px ${alpha(theme.colors.primary, 0.7)}, inset 0 2px 0 ${alpha(theme.colors.text, 0.4)}`,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            transform: `scale(${pulse})`,
          }}
        >
          <Play size={78} />
        </div>
      </div>
      <div style={{position: "absolute", left: 30, right: 30, bottom: 44, height: 10, borderRadius: 10, background: alpha(theme.colors.text, 0.14)}}>
        <div style={{width: `${18 + prog * 62}%`, height: "100%", borderRadius: 10, background: theme.colors.accent, boxShadow: `0 0 16px ${alpha(theme.colors.accent, 0.7)}`}} />
      </div>
    </Glass>
  );
};

/** Google-style search window (generic search UI). */
const SearchCard: React.FC<{delay: number}> = ({delay}) => {
  const {frame, s} = useT();
  const typed = "search";
  const n = Math.max(0, Math.min(typed.length, Math.floor((frame - delay - s(0.45)) / s(0.1))));
  const caret = Math.floor(frame / s(0.5)) % 2 === 0;
  return (
    <Glass w={CARD_W} h={CARD_H}>
      <WindowBar label="Google" />
      <div
        style={{
          position: "absolute",
          left: 34,
          right: 34,
          top: 92,
          height: 82,
          borderRadius: theme.radius.pill,
          background: alpha(theme.colors.text, 0.1),
          border: `1.5px solid ${alpha(theme.colors.accent, 0.5)}`,
          display: "flex",
          alignItems: "center",
          padding: "0 28px",
          gap: 18,
          boxShadow: `0 0 36px ${alpha(theme.colors.accent, 0.18)}`,
        }}
      >
        <SearchIcon size={42} />
        <div style={{fontFamily: theme.fonts.body, fontWeight: theme.weights.strong, fontSize: 38, color: theme.colors.text, letterSpacing: 0}}>
          {typed.slice(0, n)}
          <span style={{display: "inline-block", width: 3, height: 38, marginLeft: 4, verticalAlign: "middle", background: caret ? theme.colors.accent : "transparent"}} />
        </div>
      </div>
      {[0, 1, 2].map((i) => {
        const p = useSpring(delay + s(0.9) + i * s(0.14), theme.spring.snappy);
        return (
          <div key={i} style={{position: "absolute", left: 40, right: 40, top: 212 + i * 62, opacity: Math.min(1, p * 1.5), transform: `translateX(${interpolate(p, [0, 1], [-24, 0])}px)`}}>
            <div style={{width: `${68 - i * 12}%`, height: 14, borderRadius: 8, background: alpha(i === 0 ? theme.colors.accent : theme.colors.text, i === 0 ? 0.5 : 0.22)}} />
            <div style={{width: `${92 - i * 8}%`, height: 10, borderRadius: 8, marginTop: 14, background: alpha(theme.colors.text, 0.1)}} />
          </div>
        );
      })}
    </Glass>
  );
};

/** Scene 2 — Glossy UI Mockup. Cue 2: YouTube video + Google search → "তথ্য থাকে". */
export const S2Mockup: React.FC = () => {
  const {s} = useT();
  const yt = spread(2, 2, 0); // item 1 of 2 → equal spacing across the cue
  const gg = spread(2, 2, 1); // item 2 of 2
  const cap = wordStart(2, "সেই");

  return (
    <>
      <div style={{position: "absolute", left: 0, right: 0, top: 215, display: "flex", justifyContent: "center", columnGap: 90, perspective: 2600}}>
        <Entrance delay={yt} x={-120} y={30} from={0.9} cfg={theme.spring.smooth} style={{transform: "none"}}>
          <div style={{transform: "rotateY(9deg)"}}>
            <Float amp={7} phase={0}>
              <VideoCard delay={yt} />
            </Float>
          </div>
        </Entrance>
        <Entrance delay={gg} x={120} y={30} from={0.9} cfg={theme.spring.smooth}>
          <div style={{transform: "rotateY(-9deg)"}}>
            <Float amp={7} phase={2}>
              <SearchCard delay={gg} />
            </Float>
          </div>
        </Entrance>
      </div>

      {/* labels under each card */}
      <div style={{position: "absolute", top: 700, left: 0, right: 0, display: "flex", justifyContent: "center", columnGap: 90}}>
        <div style={{width: CARD_W, display: "flex", justifyContent: "center"}}>
          <Entrance delay={yt + s(0.25)} y={24}>
            <Chip size={44} tone="accent">video দেখা</Chip>
          </Entrance>
        </div>
        <div style={{width: CARD_W, display: "flex", justifyContent: "center"}}>
          <Entrance delay={gg + s(0.25)} y={24}>
            <Chip size={44} tone="accent">search করা</Chip>
          </Entrance>
        </div>
      </div>

      {/* bridge caption → leads into the servers scene */}
      <div style={{position: "absolute", left: 0, right: 0, top: 835, display: "flex", justifyContent: "center", alignItems: "center", columnGap: 26}}>
        <WordReveal words={["সেই", "তথ্যগুলো", {t: "থাকে", kind: "grad"}]} size={80} delay={cap} per={s(0.1)} gap={28} />
        <Entrance delay={cap + s(0.4)} y={-20}>
          <ArrowDown />
        </Entrance>
      </div>

      <Sfx name="pop" at={yt} />
      <Sfx name="pop" at={gg} rate={1.12} vol={0.9} />
      <Sfx name="whoosh-soft" at={cap} />
    </>
  );
};

const ArrowDown: React.FC = () => {
  const {frame} = useT();
  const y = Math.sin(frame / 8) * 7;
  return (
    <svg width={64} height={64} viewBox="0 0 64 64" fill="none" style={{transform: `translateY(${y}px)`}}>
      <path d="M 32 10 V 50 M 14 34 L 32 52 L 50 34" stroke={theme.colors.accent} strokeWidth={7} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
};
