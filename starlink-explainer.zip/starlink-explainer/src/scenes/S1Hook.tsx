import React from "react";
import {interpolate} from "remotion";
import {Earth} from "../components/Earth";
import {Cross} from "../components/Icons";
import {Entrance, useProgress, useSpring} from "../components/Motion";
import {Orbit} from "../components/Orbit";
import {Sfx} from "../components/Sfx";
import {Chip, WordReveal} from "../components/Text";
import {useT} from "../components/useT";
import {lineStart, wordStart} from "../timing";
import {alpha, theme} from "../theme";

/** Scene 1 — HOOK (Kinetic Typography). Cue 1. */
export const S1Hook: React.FC = () => {
  const {frame, s} = useT();
  const phaseB = lineStart(1, 1); // "Starlink কিন্তু নিজে internet তৈরি করে না।" begins
  const strikeAt = wordStart(1, "তৈরি");

  // Phase A leaves quickly just before phase B (exit faster than entrance)
  const aExit = interpolate(frame, [phaseB - s(0.3), phaseB], [0, 1], {
    easing: theme.ease.in,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  const strike = useProgress(strikeAt, 0.35);
  const badge = useSpring(strikeAt + s(0.28), theme.spring.bouncy);

  return (
    <>
      <Earth delay={0} />
      <Orbit cy={470} />

      {/* Phase A — "একটা বিষয় পরিষ্কার" */}
      {frame < phaseB + 2 && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 30,
            opacity: 1 - aExit,
            transform: `translateY(${-34 * aExit}px) scale(${1 + 0.03 * aExit})`,
            filter: `blur(${aExit * 6}px)`,
          }}
        >
          <Entrance delay={0} y={24} from={0.9}>
            <Chip size={44} tone="accent">প্রথমেই</Chip>
          </Entrance>
          <WordReveal words={["একটা", "বিষয়", {t: "পরিষ্কার", kind: "grad"}]} size={158} delay={s(0.1)} per={s(0.13)} gap={40} />
        </div>
      )}

      {/* Phase B — "Starlink  internet তৈরি করে না" */}
      {frame >= phaseB && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 26,
            paddingBottom: 30,
          }}
        >
          <Entrance delay={phaseB + s(0.03)} y={50} from={1.22} blur={14} cfg={theme.spring.bouncy}>
            <div
              style={{
                fontFamily: theme.fonts.display,
                fontWeight: theme.weights.hero,
                fontSize: 236,
                lineHeight: 1.15,
                letterSpacing: 0,
                background: `linear-gradient(95deg, ${theme.colors.primary} 0%, ${theme.colors.accent} 100%)`,
                WebkitBackgroundClip: "text",
                backgroundClip: "text",
                WebkitTextFillColor: "transparent",
                filter: `drop-shadow(0 0 50px ${alpha(theme.colors.primary, 0.45)})`,
                padding: "0 0.05em 0.1em",
              }}
            >
              Starlink
            </div>
          </Entrance>

          <div style={{display: "flex", alignItems: "center", columnGap: 34}}>
            <Entrance delay={phaseB + s(0.28)} y={34}>
              <div style={{position: "relative"}}>
                <Chip size={92} tone="dim" style={{color: strike > 0.6 ? theme.colors.textDim : theme.colors.text}}>
                  internet
                </Chip>
                <div
                  style={{
                    position: "absolute",
                    left: -14,
                    top: "52%",
                    height: 8,
                    width: `calc(${strike * 100}% + 28px)`,
                    borderRadius: 8,
                    background: theme.colors.accent,
                    boxShadow: `0 0 24px ${alpha(theme.colors.accent, 0.8)}`,
                    transform: "rotate(-2deg)",
                  }}
                />
                <div
                  style={{
                    position: "absolute",
                    right: -30,
                    top: -34,
                    width: 74,
                    height: 74,
                    borderRadius: "50%",
                    background: theme.colors.bgAlt,
                    border: `2px solid ${alpha(theme.colors.text, 0.5)}`,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    opacity: Math.min(1, badge * 1.6),
                    transform: `scale(${interpolate(badge, [0, 1], [0.3, 1])})`,
                    boxShadow: `0 14px 30px ${alpha(theme.colors.ink, 0.5)}`,
                  }}
                >
                  <Cross size={42} stroke={24} />
                </div>
              </div>
            </Entrance>
            <WordReveal words={["তৈরি", "করে", "না"]} size={96} weight={theme.weights.strong} delay={phaseB + s(0.4)} per={s(0.1)} gap={24} />
          </div>
        </div>
      )}

      <Sfx name="whoosh-soft" at={s(0.05)} />
      <Sfx name="thud" at={phaseB + s(0.03)} vol={0.85} />
      <Sfx name="click" at={strikeAt + s(0.25)} />
    </>
  );
};
