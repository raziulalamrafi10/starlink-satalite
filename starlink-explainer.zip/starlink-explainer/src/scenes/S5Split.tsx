import React from "react";
import {interpolate} from "remotion";
import {Glass} from "../components/Glass";
import {Cable, Cross, House, Satellite, Tower} from "../components/Icons";
import {Entrance, Float, useProgress, useSpring} from "../components/Motion";
import {Sfx} from "../components/Sfx";
import {Chip} from "../components/Text";
import {useT} from "../components/useT";
import {spread, wordStart} from "../timing";
import {alpha, theme} from "../theme";

const PANEL_W = 790;
const PANEL_H = 690;
const PANEL_TOP = 215;
const LEFT_X = 110;
const RIGHT_X = 1020;

/** One "not available" row: icon + label + ✕ that lands shortly after. */
const NoRow: React.FC<{at: number; label: string; icon: React.ReactNode; top: number}> = ({at, label, icon, top}) => {
  const {s} = useT();
  const x = useSpring(at + s(0.35), theme.spring.bouncy);
  const dim = useProgress(at + s(0.4), 0.4);
  return (
    <div style={{position: "absolute", left: 50, right: 50, top}}>
      <Entrance delay={at} x={-50} y={14}>
        <div
          style={{
            height: 220,
            borderRadius: theme.radius.md,
            background: alpha(theme.colors.text, 0.06),
            border: `1.5px solid ${alpha(theme.colors.muted, 0.55)}`,
            display: "flex",
            alignItems: "center",
            padding: "0 30px",
            columnGap: 24,
            position: "relative",
            opacity: interpolate(dim, [0, 1], [1, 0.62]),
          }}
        >
          <div style={{width: 120, height: 120, flexShrink: 0}}>{icon}</div>
          <div style={{fontFamily: theme.fonts.display, fontWeight: theme.weights.hero, fontSize: 58, letterSpacing: 0, lineHeight: 1.3, color: theme.colors.text, whiteSpace: "nowrap"}}>{label}</div>
          <div
            style={{
              position: "absolute",
              right: 28,
              width: 76,
              height: 76,
              borderRadius: "50%",
              background: theme.colors.bgAlt,
              border: `2px solid ${alpha(theme.colors.text, 0.5)}`,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              opacity: Math.min(1, x * 1.6),
              transform: `scale(${interpolate(x, [0, 1], [0.3, 1])})`,
              boxShadow: `0 14px 30px ${alpha(theme.colors.ink, 0.5)}`,
            }}
          >
            <Cross size={44} stroke={22} />
          </div>
        </div>
      </Entrance>
    </div>
  );
};

/** Scene 5 — Before / After split. Cue 5: no broadband / mobile tower nearby → satellite reaches you. */
export const S5Split: React.FC = () => {
  const {frame, s} = useT();
  const bbAt = spread(5, 2, 0); // broadband
  const mtAt = spread(5, 2, 1); // mobile tower
  const noAt = wordStart(5, "না থাকলেও");
  const satAt = wordStart(5, "satellite");
  const beam = useProgress(satAt + s(0.2), 0.55);
  const lit = useProgress(satAt + s(0.7), 0.5);
  const houseAt = s(0.25);
  const bob = Math.sin(frame / 10) * 0.04;

  return (
    <>
      {/* panels */}
      <div style={{position: "absolute", left: LEFT_X, top: PANEL_TOP}}>
        <Entrance delay={0} x={-60} y={20} from={0.95}>
          <Glass w={PANEL_W} h={PANEL_H} dim style={{background: `linear-gradient(150deg, ${alpha(theme.colors.text, 0.05)}, ${alpha(theme.colors.bgAlt, 0.5)})`}} />
        </Entrance>
      </div>
      <div style={{position: "absolute", left: RIGHT_X, top: PANEL_TOP}}>
        <Entrance delay={s(0.1)} x={60} y={20} from={0.95}>
          <Glass w={PANEL_W} h={PANEL_H} glow />
        </Entrance>
      </div>

      {/* headers */}
      <div style={{position: "absolute", left: LEFT_X, top: 100, width: PANEL_W, display: "flex", justifyContent: "center"}}>
        {frame >= noAt - 1 && (
          <Entrance delay={noAt} y={20}>
            <Chip size={58} tone="dim">না থাকলেও</Chip>
          </Entrance>
        )}
      </div>
      <div style={{position: "absolute", left: RIGHT_X, top: 100, width: PANEL_W, display: "flex", justifyContent: "center"}}>
        {frame >= satAt - 1 && (
          <Entrance delay={satAt} y={20}>
            <Chip size={58} tone="accent">satellite এর মাধ্যমে</Chip>
          </Entrance>
        )}
      </div>

      {/* left: broadband / mobile tower — both marked ✕ */}
      <div style={{position: "absolute", left: LEFT_X, top: PANEL_TOP, width: PANEL_W, height: PANEL_H}}>
        <NoRow at={bbAt} label="broadband" icon={<Cable size={120} />} top={80} />
        <NoRow at={mtAt} label="mobile tower" icon={<Tower size={120} />} top={360} />
      </div>

      {/* right: house (you) + satellite beam */}
      <div style={{position: "absolute", left: RIGHT_X, top: PANEL_TOP, width: PANEL_W, height: PANEL_H}}>
        {/* beam */}
        <div
          style={{
            position: "absolute",
            left: PANEL_W / 2 - 180,
            top: 235,
            width: 360,
            height: 280,
            transformOrigin: "50% 0%",
            transform: `scaleY(${beam})`,
            opacity: beam,
            clipPath: "polygon(44% 0, 56% 0, 100% 100%, 0 100%)",
            background: `linear-gradient(180deg, ${alpha(theme.colors.accent, 0.6)}, ${alpha(theme.colors.primary, 0.05)})`,
          }}
        />
        {/* satellite */}
        <div style={{position: "absolute", left: PANEL_W / 2 - 125, top: 40}}>
          <Entrance delay={satAt} y={-60} from={0.5} cfg={theme.spring.bouncy}>
            <Float amp={8} phase={1}>
              <div style={{filter: `drop-shadow(0 0 44px ${alpha(theme.colors.primary, 0.65)})`}}>
                <Satellite size={250} uid="s5" />
              </div>
            </Float>
          </Entrance>
        </div>
        {/* house = you */}
        <div style={{position: "absolute", left: PANEL_W / 2 - 130, top: 335}}>
          <Entrance delay={houseAt} y={40} from={0.85}>
            <div style={{transform: `scale(${1 + bob * lit})`, filter: `drop-shadow(0 0 ${40 * lit}px ${alpha(theme.colors.accent, 0.65)})`}}>
              <House size={260} />
            </div>
          </Entrance>
        </div>
        <div style={{position: "absolute", left: 0, right: 0, top: 595, display: "flex", justifyContent: "center"}}>
          <Entrance delay={houseAt + s(0.2)} y={16}>
            <Chip size={38}>আপনি</Chip>
          </Entrance>
        </div>
      </div>

      <Sfx name="click" at={bbAt + s(0.35)} />
      <Sfx name="click" at={mtAt + s(0.35)} vol={0.95} rate={1.06} />
      <Sfx name="pop" at={satAt} rate={1.05} />
    </>
  );
};
