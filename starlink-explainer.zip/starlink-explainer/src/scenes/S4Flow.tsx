import React from "react";
import {interpolate} from "remotion";
import {Glass} from "../components/Glass";
import {Laptop, Satellite, ServerRack} from "../components/Icons";
import {Entrance, Float, useProgress} from "../components/Motion";
import {Sfx} from "../components/Sfx";
import {Chip, WordReveal} from "../components/Text";
import {useT} from "../components/useT";
import {spread, wordStart} from "../timing";
import {alpha, theme} from "../theme";

// quadratic path: device → (satellite at apex) → server
const P0 = {x: 545, y: 585};
const P1 = {x: 850, y: 30};
const P2 = {x: 1150, y: 585};
const bez = (t: number) => ({
  x: (1 - t) * (1 - t) * P0.x + 2 * (1 - t) * t * P1.x + t * t * P2.x,
  y: (1 - t) * (1 - t) * P0.y + 2 * (1 - t) * t * P1.y + t * t * P2.y,
});
const PATH_LEN = (() => {
  let L = 0;
  let prev = bez(0);
  for (let i = 1; i <= 80; i++) {
    const c = bez(i / 80);
    L += Math.hypot(c.x - prev.x, c.y - prev.y);
    prev = c;
  }
  return L;
})();
const PATH_D = `M ${P0.x} ${P0.y} Q ${P1.x} ${P1.y} ${P2.x} ${P2.y}`;
const APEX = bez(0.5);

/** Scene 4 — Process Flow. Cue 4: Starlink links YOU to Facebook / YouTube servers. */
export const S4Flow: React.FC = () => {
  const {frame, fps, s} = useT();
  const fbAt = spread(4, 2, 0);
  const ytAt = spread(4, 2, 1);
  const youAt = wordStart(4, "সঙ্গে"); // device tile ("আপনি") + satellite arrive just before the link
  const satAt = youAt + s(0.2);
  const headAt = wordStart(4, "আপনাকে");
  const drawAt = headAt + s(0.05); // link draws while "আপনাকে ... যুক্ত করা" is spoken
  const drawDur = 0.75;
  const draw = useProgress(drawAt, drawDur, theme.ease.inOut);
  const doneAt = drawAt + s(drawDur);
  const linked = frame >= doneAt ? 1 : 0;
  const glow = useProgress(doneAt, 0.5);

  return (
    <>
      {/* headline */}
      <div style={{position: "absolute", left: 0, right: 0, top: 78, display: "flex", justifyContent: "center"}}>
        {frame >= headAt - 1 && <WordReveal words={["আপনাকে", {t: "যুক্ত", kind: "grad"}, "করা"]} size={104} delay={headAt} per={s(0.08)} gap={34} />}
      </div>

      {/* link path */}
      <svg width={1920} height={1080} style={{position: "absolute", inset: 0, overflow: "visible"}}>
        <path d={PATH_D} fill="none" stroke={alpha(theme.colors.text, 0.12)} strokeWidth={4} strokeDasharray="2 14" strokeLinecap="round" />
        <path
          d={PATH_D}
          fill="none"
          stroke={theme.colors.accent}
          strokeWidth={6}
          strokeLinecap="round"
          strokeDasharray={PATH_LEN}
          strokeDashoffset={PATH_LEN * (1 - draw)}
          style={{filter: `drop-shadow(0 0 14px ${alpha(theme.colors.accent, 0.8)})`}}
        />
        {linked === 1 &&
          [0, 1, 2].map((i) => {
            const t = (((frame - doneAt) / (fps * 1.7)) + i / 3) % 1;
            const pt = bez(t);
            const o = interpolate(t, [0, 0.08, 0.92, 1], [0, 1, 1, 0]);
            return <circle key={i} cx={pt.x} cy={pt.y} r={9} fill={theme.colors.text} opacity={o} style={{filter: `drop-shadow(0 0 12px ${theme.colors.accent})`}} />;
          })}
      </svg>

      {/* device (you) */}
      <div style={{position: "absolute", left: 220, top: 420}}>
        <Entrance delay={youAt} x={-60} y={20} from={0.9}>
          <Float amp={5} phase={1}>
            <Glass w={330} h={330} radius={theme.radius.lg}>
              <div style={{position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center"}}>
                <Laptop size={230} />
              </div>
            </Glass>
          </Float>
        </Entrance>
        <div style={{display: "flex", justifyContent: "center", marginTop: 26}}>
          <Entrance delay={youAt + s(0.18)} y={20}>
            <Chip size={44}>আপনি</Chip>
          </Entrance>
        </div>
      </div>

      {/* satellite node on the path apex */}
      <div style={{position: "absolute", left: APEX.x - 105, top: APEX.y - 105}}>
        <Entrance delay={satAt} y={-30} from={0.5} cfg={theme.spring.bouncy}>
          <Float amp={7} phase={2}>
            <div style={{filter: `drop-shadow(0 0 40px ${alpha(theme.colors.primary, 0.6)})`}}>
              <Satellite size={210} uid="s4" />
            </div>
          </Float>
        </Entrance>
      </div>
      <div style={{position: "absolute", left: APEX.x - 120, top: APEX.y + 130, width: 240, display: "flex", justifyContent: "center"}}>
        <Entrance delay={satAt + s(0.15)} y={20}>
          <Chip size={40} tone="accent">Starlink</Chip>
        </Entrance>
      </div>

      {/* server cluster */}
      <div style={{position: "absolute", left: 1160, top: 380}}>
        <Entrance delay={0} x={60} y={20} from={0.92}>
          <Float amp={5} phase={3}>
            <Glass w={340} h={400} radius={theme.radius.lg} glow={linked === 1}>
              <div style={{position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center"}}>
                <ServerRack size={290} leds={0.2 + glow * 0.8} />
              </div>
              {linked === 1 && (
                <div style={{position: "absolute", inset: 0, boxShadow: `inset 0 0 ${60 * glow}px ${alpha(theme.colors.accent, 0.35 * glow)}`, borderRadius: theme.radius.lg}} />
              )}
            </Glass>
          </Float>
        </Entrance>
        <div style={{position: "absolute", left: 0, right: 0, top: -74, display: "flex", justifyContent: "center"}}>
          <Entrance delay={s(0.05)} y={16}>
            <Chip size={40} tone="dim">network</Chip>
          </Entrance>
        </div>
      </div>

      {/* named services (equal spacing across the cue) */}
      <div style={{position: "absolute", left: 1470, top: 430}}>
        <Entrance delay={fbAt} x={50} y={10}>
          <Chip size={46} tone="accent">Facebook</Chip>
        </Entrance>
      </div>
      <div style={{position: "absolute", left: 1470, top: 610}}>
        <Entrance delay={ytAt} x={50} y={10}>
          <Chip size={46} tone="accent">YouTube</Chip>
        </Entrance>
      </div>

      <Sfx name="pop" at={fbAt} />
      <Sfx name="pop" at={ytAt} rate={1.12} vol={0.9} />
      <Sfx name="pop" at={youAt} rate={0.94} />
      <Sfx name="chime" at={doneAt - s(0.05)} />
    </>
  );
};
