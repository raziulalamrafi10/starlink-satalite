// theme.ts — single source of truth: colours, easings, springs, fonts, SFX levels.
// Colour scheme: "Deep Space" (user's choice #1). No hex values anywhere else.
import {Easing} from "remotion";

export const theme = {
  colors: {
    bg: "#050B1A", // background
    bgAlt: "#0A1630",
    primary: "#4F8CFF", // hero
    accent: "#22D3EE", // accent
    text: "#F1F5FF", // text
    textDim: "#9FB0D0", // derived neutral
    muted: "#5A6B8F", // derived neutral (disabled / "not available")
    ink: "#000000", // for shadows & vignette only
  },
  fonts: {
    display: "'Hind Siliguri', sans-serif",
    body: "'Hind Siliguri', sans-serif",
  },
  weights: {hero: 700, strong: 600, body: 500},
  radius: {sm: 18, md: 28, lg: 40, pill: 999},
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1), // entrances / moves
    inOut: Easing.bezier(0.83, 0, 0.17, 1), // slow drifts
    in: Easing.bezier(0.7, 0, 0.84, 0), // exits only
  },
  spring: {
    snappy: {damping: 14, stiffness: 160, mass: 0.6},
    smooth: {damping: 20, stiffness: 90, mass: 1},
    bouncy: {damping: 11, stiffness: 170, mass: 0.7},
  },
  // Durations in SECONDS; converted with fps at use time.
  dur: {exit: 0.3, enter: 0.6},
  // SFX mix levels (kept low so the voiceover is never covered)
  sfx: {
    pop: 0.32,
    click: 0.3,
    whoosh: 0.26,
    "whoosh-soft": 0.24,
    chime: 0.28,
    thud: 0.22,
  },
} as const;

/** hex + alpha(0..1) → #RRGGBBAA */
export const alpha = (hex: string, a: number) =>
  hex + Math.round(Math.max(0, Math.min(1, a)) * 255).toString(16).padStart(2, "0");

export type SfxName = keyof typeof theme.sfx;
