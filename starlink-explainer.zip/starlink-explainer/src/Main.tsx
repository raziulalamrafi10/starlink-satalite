import React from "react";
import {AbsoluteFill, Sequence} from "remotion";
import {Bg, Grade, Grain, Vignette} from "./components/Layers";
import {SceneShell} from "./components/Motion";
import {PreviewAudio} from "./components/Sfx";
import {Sweep} from "./components/Sweep";
import {S1Hook} from "./scenes/S1Hook";
import {S2Mockup} from "./scenes/S2Mockup";
import {S3Globe} from "./scenes/S3Globe";
import {S4Flow} from "./scenes/S4Flow";
import {S5Split} from "./scenes/S5Split";
import {S6Online} from "./scenes/S6Online";
import {SCENES} from "./timing";

const SCENE_COMPONENTS: React.FC[] = [S1Hook, S2Mockup, S3Globe, S4Flow, S5Split, S6Online];

export const Main: React.FC = () => {
  return (
    <AbsoluteFill style={{backgroundColor: "#000"}}>
      {/* L1 background (continuous) */}
      <Bg />
      {/* L2-3 scenes: assets + graphics + type */}
      {SCENES.map((sc, i) => {
        const Comp = SCENE_COMPONENTS[i];
        if (!Comp) return null;
        return (
          <Sequence key={i} from={sc.from} durationInFrames={sc.duration} name={`Scene ${i + 1}`}>
            <SceneShell last={i === SCENES.length - 1}>
              <Comp />
            </SceneShell>
          </Sequence>
        );
      })}
      {/* transitions between scenes */}
      {SCENES.slice(1).map((sc, i) => (
        <Sweep key={i} at={sc.from} />
      ))}
      {/* L4 grade, L5 grain + vignette */}
      <Grade />
      <Grain />
      <Vignette />
      <PreviewAudio />
    </AbsoluteFill>
  );
};
