// Source of truth for ALL timing. Generated from the user's SRT (src/data/script.srt).
export const SRT = `1
00:00:00,140 --> 00:00:06,500
প্রথমেই একটা বিষয় পরিষ্কার করা যাক।
Starlink কিন্তু নিজে internet তৈরি করে না।

2
00:00:06,500 --> 00:00:12,000
আপনি যে YouTube এ video দেখেন কিংবা
Google এ search করেন সেই তথ্যগুলো থাকে

3
00:00:12,000 --> 00:00:18,300
পৃথিবীর বিভিন্ন server ও data center এ।
Starlink এর কাজ হলো পৃথিবীর সেই internet

4
00:00:18,300 --> 00:00:24,120
network অর্থাৎ Facebook বা YouTube এর
server এর সঙ্গে আপনাকে এমনভাবে যুক্ত করা

5
00:00:24,120 --> 00:00:29,580
যাতে আপনার কাছাকাছি broadband বা mobile
tower না থাকলেও satellite এর মাধ্যমে

6
00:00:29,580 --> 00:00:31,140
online যাওয়া সম্ভব হয়।`;
