// Generic UI/space icons drawn in code with theme colours. (No brand logos are drawn.)
import React from "react";
import {alpha, theme} from "../theme";

type P = {size?: number; style?: React.CSSProperties};
const C = theme.colors;

const Svg: React.FC<P & {children: React.ReactNode; id?: string}> = ({size = 200, style, children}) => (
  <svg width={size} height={size} viewBox="0 0 200 200" fill="none" style={{overflow: "visible", ...style}}>
    {children}
  </svg>
);

export const Satellite: React.FC<P & {uid?: string}> = ({size, style, uid = "sat"}) => (
  <Svg size={size} style={style}>
    <defs>
      <linearGradient id={`${uid}-panel`} x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor={alpha(C.primary, 0.55)} />
        <stop offset="1" stopColor={alpha(C.accent, 0.3)} />
      </linearGradient>
      <linearGradient id={`${uid}-body`} x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor={alpha(C.text, 0.95)} />
        <stop offset="1" stopColor={alpha(C.textDim, 0.85)} />
      </linearGradient>
    </defs>
    <g transform="rotate(-32 100 100)">
      {[0, 1].map((side) => {
        const x = side === 0 ? 6 : 132;
        return (
          <g key={side}>
            <rect x={x} y={80} width={62} height={40} rx={5} fill={`url(#${uid}-panel)`} stroke={C.accent} strokeWidth={2.5} />
            {[1, 2, 3].map((k) => (
              <line key={k} x1={x + k * 15.5} y1={80} x2={x + k * 15.5} y2={120} stroke={alpha(C.text, 0.35)} strokeWidth={1.5} />
            ))}
            <line x1={x} y1={100} x2={x + 62} y2={100} stroke={alpha(C.text, 0.35)} strokeWidth={1.5} />
          </g>
        );
      })}
      <rect x={70} y={70} width={60} height={60} rx={13} fill={`url(#${uid}-body)`} stroke={C.text} strokeWidth={2} />
      <circle cx={100} cy={100} r={9} fill={C.accent} />
      <line x1={100} y1={70} x2={100} y2={48} stroke={C.text} strokeWidth={4} strokeLinecap="round" />
      <path d="M 82 42 Q 100 62 118 42" stroke={C.text} strokeWidth={4.5} strokeLinecap="round" fill="none" />
      <circle cx={100} cy={40} r={4} fill={C.accent} />
    </g>
  </Svg>
);

export const ServerRack: React.FC<P & {leds?: number}> = ({size, style, leds = 1}) => (
  <Svg size={size} style={style}>
    {[0, 1, 2].map((i) => (
      <g key={i}>
        <rect x={22} y={24 + i * 52} width={156} height={42} rx={11} fill={alpha(C.text, 0.1)} stroke={alpha(C.text, 0.55)} strokeWidth={2.5} />
        <circle cx={46} cy={45 + i * 52} r={5.5} fill={C.accent} opacity={0.35 + 0.65 * leds} />
        <circle cx={64} cy={45 + i * 52} r={5.5} fill={C.muted} />
        <line x1={92} y1={45 + i * 52} x2={160} y2={45 + i * 52} stroke={alpha(C.text, 0.4)} strokeWidth={3} strokeLinecap="round" />
      </g>
    ))}
  </Svg>
);

export const Laptop: React.FC<P> = ({size, style}) => (
  <Svg size={size} style={style}>
    <rect x={34} y={38} width={132} height={92} rx={11} fill={alpha(C.bgAlt, 0.9)} stroke={C.text} strokeWidth={3} />
    <rect x={44} y={48} width={112} height={72} rx={5} fill={alpha(C.primary, 0.22)} />
    <path d="M 16 142 H 184 L 170 160 H 30 Z" fill={alpha(C.text, 0.2)} stroke={C.text} strokeWidth={3} strokeLinejoin="round" />
    <path d="M 76 90 Q 100 66 124 90 M 86 100 Q 100 86 114 100" stroke={C.accent} strokeWidth={5} strokeLinecap="round" />
    <circle cx={100} cy={110} r={4.5} fill={C.accent} />
  </Svg>
);

export const Tower: React.FC<P> = ({size, style}) => (
  <Svg size={size} style={style}>
    <path d="M 100 46 L 62 172 M 100 46 L 138 172" stroke={C.text} strokeWidth={5} strokeLinecap="round" />
    {[88, 122, 154].map((y) => {
      const half = 6 + ((y - 46) / 126) * 32;
      return <line key={y} x1={100 - half} y1={y} x2={100 + half} y2={y} stroke={C.text} strokeWidth={4} strokeLinecap="round" />;
    })}
    <path d="M 100 88 L 78 122 M 100 88 L 122 122 M 78 122 L 122 154 M 122 122 L 78 154" stroke={alpha(C.text, 0.6)} strokeWidth={3} />
    <circle cx={100} cy={40} r={8} fill={C.accent} />
    <path d="M 72 24 Q 58 40 72 56 M 52 12 Q 26 40 52 68 M 128 24 Q 142 40 128 56 M 148 12 Q 174 40 148 68" stroke={C.text} strokeWidth={5} strokeLinecap="round" />
  </Svg>
);

export const Cable: React.FC<P> = ({size, style}) => (
  <Svg size={size} style={style}>
    <rect x={54} y={30} width={92} height={82} rx={12} fill={alpha(C.text, 0.12)} stroke={C.text} strokeWidth={4} />
    {[0, 1, 2, 3, 4, 5].map((i) => (
      <line key={i} x1={68 + i * 13} y1={44} x2={68 + i * 13} y2={72} stroke={C.accent} strokeWidth={4.5} strokeLinecap="round" />
    ))}
    <rect x={76} y={112} width={48} height={30} rx={7} fill={alpha(C.text, 0.2)} stroke={C.text} strokeWidth={4} />
    <path d="M 100 142 C 100 176 60 160 56 190" stroke={C.text} strokeWidth={9} strokeLinecap="round" fill="none" />
  </Svg>
);

export const House: React.FC<P> = ({size, style}) => (
  <Svg size={size} style={style}>
    <path d="M 36 108 L 100 52 L 164 108 V 170 H 36 Z" fill={alpha(C.text, 0.1)} stroke={C.text} strokeWidth={4} strokeLinejoin="round" />
    <rect x={82} y={124} width={36} height={46} rx={6} fill={alpha(C.primary, 0.3)} stroke={C.text} strokeWidth={3.5} />
    <g transform="rotate(-28 150 52)">
      <path d="M 128 44 Q 150 82 172 44 Z" fill={alpha(C.accent, 0.35)} stroke={C.accent} strokeWidth={4} strokeLinejoin="round" />
      <line x1={150} y1={62} x2={150} y2={30} stroke={C.accent} strokeWidth={4} strokeLinecap="round" />
      <circle cx={150} cy={28} r={5} fill={C.text} />
    </g>
  </Svg>
);

export const Check: React.FC<P & {color?: string; stroke?: number}> = ({size, style, color = C.bg, stroke = 22}) => (
  <Svg size={size} style={style}>
    <path d="M 38 104 L 84 148 L 164 56" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" />
  </Svg>
);

export const Cross: React.FC<P & {color?: string; stroke?: number}> = ({size, style, color = C.text, stroke = 20}) => (
  <Svg size={size} style={style}>
    <path d="M 52 52 L 148 148 M 148 52 L 52 148" stroke={color} strokeWidth={stroke} strokeLinecap="round" />
  </Svg>
);

export const Play: React.FC<P & {color?: string}> = ({size, style, color = C.text}) => (
  <Svg size={size} style={style}>
    <path d="M 70 46 L 154 100 L 70 154 Z" fill={color} stroke={color} strokeWidth={10} strokeLinejoin="round" />
  </Svg>
);

export const SearchIcon: React.FC<P> = ({size, style}) => (
  <Svg size={size} style={style}>
    <circle cx={88} cy={88} r={46} stroke={C.text} strokeWidth={14} />
    <line x1={124} y1={124} x2={166} y2={166} stroke={C.text} strokeWidth={16} strokeLinecap="round" />
  </Svg>
);

/** A small pin dot with pulsing ring. */
export const Pin: React.FC<{size?: number; pulse?: number; color?: string}> = ({size = 26, pulse = 0, color = C.accent}) => (
  <div style={{position: "relative", width: size, height: size}}>
    <div
      style={{
        position: "absolute",
        inset: -size * 0.6 * pulse,
        borderRadius: "50%",
        border: `2px solid ${alpha(color, 0.7 * (1 - pulse))}`,
        transform: `scale(${1 + pulse})`,
        opacity: 1 - pulse,
      }}
    />
    <div style={{position: "absolute", inset: 0, borderRadius: "50%", background: color, boxShadow: `0 0 28px ${alpha(color, 0.8)}`}} />
  </div>
);
