import React from "react";
import {alpha, theme} from "../theme";
import {Satellite} from "./Icons";
import {useT} from "./useT";

/** Tilted orbit ellipse with a satellite travelling along it (rendered behind text). */
export const Orbit: React.FC<{cx?: number; cy?: number; rx?: number; ry?: number; tilt?: number; seconds?: number; satSize?: number; opacity?: number; start?: number}> = ({
  cx = 960,
  cy = 520,
  rx = 780,
  ry = 210,
  tilt = -9,
  seconds = 10,
  satSize = 170,
  opacity = 1,
  start = 1.2,
}) => {
  const {frame, fps} = useT();
  const th = start + (Math.PI * 2 * frame) / (fps * seconds);
  const x = Math.cos(th) * rx;
  const y = Math.sin(th) * ry;
  const near = 0.5 + 0.5 * Math.sin(th); // 1 = in front
  const sc = 0.62 + 0.38 * near;
  return (
    <div style={{position: "absolute", left: cx, top: cy, width: 0, height: 0, opacity, transform: `rotate(${tilt}deg)`}}>
      <svg width={rx * 2 + 80} height={ry * 2 + 80} style={{position: "absolute", left: -rx - 40, top: -ry - 40, overflow: "visible"}}>
        <ellipse cx={rx + 40} cy={ry + 40} rx={rx} ry={ry} fill="none" stroke={alpha(theme.colors.accent, 0.4)} strokeWidth={2.5} strokeDasharray="4 14" strokeLinecap="round" />
        <ellipse cx={rx + 40} cy={ry + 40} rx={rx - 40} ry={ry - 14} fill="none" stroke={alpha(theme.colors.text, 0.1)} strokeWidth={1.5} />
      </svg>
      <div
        style={{
          position: "absolute",
          left: x - satSize / 2,
          top: y - satSize / 2,
          transform: `rotate(${-tilt}deg) scale(${sc})`,
          filter: `drop-shadow(0 0 30px ${alpha(theme.colors.primary, 0.55)})`,
          opacity: 0.55 + 0.45 * near,
        }}
      >
        <Satellite size={satSize} uid="orbit" />
      </div>
    </div>
  );
};
