import React from "react";
import {alpha, theme} from "../theme";
import {useProgress} from "./Motion";

/** Earth limb glowing at the bottom of the frame (bookend visual for hook + ending). */
export const Earth: React.FC<{delay?: number; rise?: number}> = ({delay = 0, rise = 240}) => {
  const p = useProgress(delay, 1.1);
  const size = 2800;
  return (
    <div
      style={{
        position: "absolute",
        left: (1920 - size) / 2,
        top: 1080 - rise * p,
        width: size,
        height: size,
        borderRadius: "50%",
        background: `radial-gradient(circle at 50% 0%, ${alpha(theme.colors.accent, 0.42)} 0%, ${alpha(theme.colors.primary, 0.26)} 6%, ${alpha(theme.colors.bgAlt, 0.95)} 22%, ${theme.colors.bg} 46%)`,
        boxShadow: `inset 0 3px 0 ${alpha(theme.colors.accent, 0.85)}, 0 -34px 130px ${alpha(theme.colors.primary, 0.5)}`,
        opacity: Math.min(1, p * 1.6),
      }}
    />
  );
};
