import {useCurrentFrame, useVideoConfig} from "remotion";

/** frame + fps + seconds→frames helper. All durations in components go through s(). */
export const useT = () => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();
  const s = (sec: number) => Math.round(sec * fps);
  return {frame, fps, s, dur: durationInFrames};
};
