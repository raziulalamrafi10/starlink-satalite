import React, {useEffect, useState} from "react";
import {Audio, Sequence, continueRender, delayRender, getRemotionEnvironment, staticFile, useVideoConfig} from "remotion";
import {SFX_ENABLED, VO_IN_PREVIEW, VO_IN_RENDER} from "../config";
import {SfxName, theme} from "../theme";

/** Short UI sound at scene-local frame `at`. Level comes from theme.sfx (kept low). */
export const Sfx: React.FC<{name: SfxName; at: number; rate?: number; vol?: number}> = ({name, at, rate = 1, vol = 1}) => {
  const {fps} = useVideoConfig();
  if (!SFX_ENABLED) return null;
  return (
    <Sequence from={Math.max(0, Math.round(at))} durationInFrames={Math.ceil(fps * 1)} layout="none">
      <Audio src={staticFile(`sfx/${name}.wav`)} volume={theme.sfx[name] * vol} playbackRate={rate} />
    </Sequence>
  );
};

/**
 * Plays public/voiceover.mp3 if (and only if) the file exists.
 * Studio preview: controlled by VO_IN_PREVIEW. Rendering: controlled by VO_IN_RENDER (default off).
 */
export const PreviewAudio: React.FC = () => {
  const {isRendering} = getRemotionEnvironment();
  const enabled = isRendering ? VO_IN_RENDER : VO_IN_PREVIEW;
  const [exists, setExists] = useState(false);
  const [handle] = useState(() => (enabled ? delayRender("Checking voiceover.mp3") : null));

  useEffect(() => {
    if (!enabled) return;
    let alive = true;
    fetch(staticFile("voiceover.mp3"), {method: "HEAD"})
      .then((r) => {
        const type = r.headers.get("content-type") ?? "";
        if (alive) setExists(r.ok && /audio|mpeg|octet/i.test(type));
      })
      .catch(() => alive && setExists(false))
      .finally(() => handle !== null && continueRender(handle));
    return () => {
      alive = false;
    };
  }, [enabled, handle]);

  if (!enabled || !exists) return null;
  return <Audio src={staticFile("voiceover.mp3")} />;
};
