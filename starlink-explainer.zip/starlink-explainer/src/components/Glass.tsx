import React from "react";
import {alpha, theme} from "../theme";

/** Glossy glass panel: gradient fill, hairline border, top highlight, deep shadow. */
export const Glass: React.FC<{
  w?: number | string;
  h?: number | string;
  radius?: number;
  glow?: boolean;
  dim?: boolean;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({w, h, radius = theme.radius.md, glow, dim, style, children}) => (
  <div
    style={{
      width: w,
      height: h,
      borderRadius: radius,
      position: "relative",
      overflow: "hidden",
      background: `linear-gradient(150deg, ${alpha(theme.colors.text, dim ? 0.06 : 0.12)} 0%, ${alpha(theme.colors.text, 0.03)} 60%, ${alpha(theme.colors.bgAlt, 0.6)} 100%)`,
      border: `1.5px solid ${alpha(dim ? theme.colors.muted : theme.colors.text, dim ? 0.4 : 0.18)}`,
      boxShadow: [
        `inset 0 1.5px 0 ${alpha(theme.colors.text, dim ? 0.1 : 0.28)}`,
        `0 50px 90px -30px ${alpha(theme.colors.ink, 0.7)}`,
        glow ? `0 0 90px ${alpha(theme.colors.primary, 0.3)}` : "0 0 0 transparent",
      ].join(", "),
      ...style,
    }}
  >
    {children}
  </div>
);
