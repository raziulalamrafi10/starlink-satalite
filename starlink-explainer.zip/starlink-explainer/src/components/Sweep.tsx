import React from "react";
import {AbsoluteFill, Sequence, interpolate} from "remotion";
import {alpha, theme} from "../theme";
import {Sfx} from "./Sfx";
import {useT} from "./useT";

const Band: React.FC = () => {
  const {frame, s, dur} = useT();
  const x = interpolate(frame, [0, dur - 1], [-900, 2300], {easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  const o = interpolate(frame, [0, s(0.12), dur - s(0.1), dur - 1], [0, 1, 1, 0], {extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  return (
    <AbsoluteFill style={{pointerEvents: "none", opacity: o, overflow: "hidden"}}>
      <div
        style={{
          position: "absolute",
          top: -200,
          height: 1500,
          width: 520,
          left: x,
          transform: "skewX(-18deg)",
          filter: "blur(10px)",
          background: `linear-gradient(90deg, transparent, ${alpha(theme.colors.accent, 0.38)} 45%, ${alpha(theme.colors.text, 0.5)} 52%, ${alpha(theme.colors.primary, 0.3)} 60%, transparent)`,
        }}
      />
    </AbsoluteFill>
  );
};

/** Scene transition: light-band swipe + soft whoosh, centred on `at` (absolute frame). */
export const Sweep: React.FC<{at: number}> = ({at}) => {
  const {s} = useT();
  const len = s(0.5);
  const from = Math.max(0, at - s(0.2));
  return (
    <>
      <Sequence from={from} durationInFrames={len} layout="none">
        <Band />
      </Sequence>
      <Sfx name="whoosh" at={from} />
    </>
  );
};
