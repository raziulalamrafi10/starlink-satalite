import React from "react";
import {AbsoluteFill, random, useCurrentFrame} from "remotion";
import {alpha, theme} from "../theme";

/** Layer 1 — continuous background: gradient, drifting colour blobs, stars, dot-grid. */
export const Bg: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 60;
  const d2 = Math.cos(frame / 70) * 50;
  const stars = React.useMemo(
    () =>
      Array.from({length: 90}).map((_, i) => ({
        x: random(`sx${i}`) * 100,
        y: random(`sy${i}`) * 100,
        r: 1 + random(`sr${i}`) * 2,
        ph: random(`sp${i}`) * 6.28,
        depth: 0.3 + random(`sd${i}`) * 0.7,
      })),
    [],
  );
  return (
    <AbsoluteFill
      style={{background: `linear-gradient(180deg, ${theme.colors.bg} 0%, ${theme.colors.bgAlt} 100%)`}}
    >
      <div
        style={{
          position: "absolute",
          width: 1300,
          height: 1300,
          borderRadius: "50%",
          top: -560,
          left: -330 + d1,
          filter: "blur(50px)",
          background: `radial-gradient(circle, ${alpha(theme.colors.primary, 0.26)}, transparent 62%)`,
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 1000,
          height: 1000,
          borderRadius: "50%",
          bottom: -470,
          right: -280 - d2,
          filter: "blur(70px)",
          background: `radial-gradient(circle, ${alpha(theme.colors.accent, 0.16)}, transparent 65%)`,
        }}
      />
      <AbsoluteFill
        style={{
          backgroundImage: `radial-gradient(${alpha(theme.colors.text, 0.09)} 1.5px, transparent 1.6px)`,
          backgroundSize: "72px 72px",
          backgroundPosition: `${-frame * 0.25}px 0px`,
          WebkitMaskImage: "radial-gradient(ellipse at center, black 20%, transparent 75%)",
          maskImage: "radial-gradient(ellipse at center, black 20%, transparent 75%)",
        }}
      />
      {stars.map((st, i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            left: `${(st.x - frame * 0.012 * st.depth + 100) % 100}%`,
            top: `${st.y}%`,
            width: st.r,
            height: st.r,
            borderRadius: "50%",
            background: theme.colors.text,
            opacity: 0.18 + 0.4 * (0.5 + 0.5 * Math.sin(frame / 24 + st.ph)),
          }}
        />
      ))}
    </AbsoluteFill>
  );
};

/** Layer 4 — colour grade (above content). */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: "none"}}>
    <AbsoluteFill style={{backgroundColor: theme.colors.primary, mixBlendMode: "soft-light", opacity: 0.18}} />
    <AbsoluteFill
      style={{
        background: `linear-gradient(180deg, ${alpha(theme.colors.ink, 0.12)}, transparent 28%, transparent 72%, ${alpha(theme.colors.ink, 0.2)})`,
      }}
    />
  </AbsoluteFill>
);

/** Layer 5a — procedural film grain (no asset). */
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        backgroundImage: noise,
        backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.06,
        mixBlendMode: "overlay",
      }}
    />
  );
};

/** Layer 5b — vignette (topmost). */
export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      pointerEvents: "none",
      background: `radial-gradient(ellipse at center, transparent 56%, ${alpha(theme.colors.ink, 0.34)} 100%)`,
    }}
  />
);
