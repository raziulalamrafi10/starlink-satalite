import React from "react";
import {interpolate, spring} from "remotion";
import {alpha, theme} from "../theme";
import {useT} from "./useT";

export type Kind = "hero" | "accent" | "dim" | "grad";
export type Word = string | {t: string; kind?: Kind};

export const wordStyle = (kind?: Kind): React.CSSProperties => {
  switch (kind) {
    case "hero":
      return {color: theme.colors.primary, textShadow: `0 0 40px ${alpha(theme.colors.primary, 0.55)}`};
    case "accent":
      return {color: theme.colors.accent};
    case "dim":
      return {color: theme.colors.textDim};
    case "grad":
      return {
        background: `linear-gradient(95deg, ${theme.colors.primary} 0%, ${theme.colors.accent} 100%)`,
        WebkitBackgroundClip: "text",
        backgroundClip: "text",
        color: "transparent",
        WebkitTextFillColor: "transparent",
      };
    default:
      return {color: theme.colors.text};
  }
};

/**
 * Word-by-word staggered reveal. Splits ONLY on spaces (Bengali clusters are never broken).
 * letterSpacing is always 0 for Bengali safety.
 */
export const WordReveal: React.FC<{
  words: Word[] | string;
  delay?: number;
  per?: number;
  size?: number;
  weight?: number;
  gap?: number;
  align?: "center" | "flex-start" | "flex-end";
  style?: React.CSSProperties;
}> = ({words, delay = 0, per = 4, size = 96, weight = theme.weights.hero, gap = 22, align = "center", style}) => {
  const {frame, fps} = useT();
  const list: Word[] = typeof words === "string" ? words.split(" ") : words;
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: align,
        columnGap: gap,
        rowGap: 6,
        fontFamily: theme.fonts.display,
        fontSize: size,
        fontWeight: weight,
        lineHeight: 1.3,
        letterSpacing: 0,
        ...style,
      }}
    >
      {list.map((w, i) => {
        const t = typeof w === "string" ? w : w.t;
        const kind = typeof w === "string" ? undefined : w.kind;
        const p = spring({frame: frame - delay - i * per, fps, config: theme.spring.snappy});
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              padding: "0.04em 0.06em 0.2em",
              margin: "-0.04em -0.06em -0.2em",
              opacity: Math.min(1, p * 1.5),
              transform: `translateY(${interpolate(p, [0, 1], [34, 0])}px) scale(${interpolate(p, [0, 1], [0.95, 1])})`,
              filter: `blur(${Math.max(0, (1 - p) * 8)}px)`,
              whiteSpace: "nowrap",
              ...wordStyle(kind),
            }}
          >
            {t}
          </span>
        );
      })}
    </div>
  );
};

/** Small glass label chip. */
export const Chip: React.FC<{
  children: React.ReactNode;
  size?: number;
  tone?: "neutral" | "accent" | "dim";
  icon?: React.ReactNode;
  style?: React.CSSProperties;
}> = ({children, size = 38, tone = "neutral", icon, style}) => {
  const border =
    tone === "accent" ? alpha(theme.colors.accent, 0.55) : tone === "dim" ? alpha(theme.colors.muted, 0.5) : alpha(theme.colors.text, 0.2);
  const color = tone === "dim" ? theme.colors.textDim : theme.colors.text;
  return (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 14,
        padding: `${size * 0.22}px ${size * 0.6}px`,
        borderRadius: theme.radius.pill,
        background: `linear-gradient(145deg, ${alpha(theme.colors.text, 0.11)}, ${alpha(theme.colors.text, 0.04)})`,
        border: `1.5px solid ${border}`,
        boxShadow: `inset 0 1px 0 ${alpha(theme.colors.text, 0.22)}, 0 18px 40px -14px ${alpha(theme.colors.ink, 0.6)}`,
        fontFamily: theme.fonts.body,
        fontWeight: theme.weights.strong,
        fontSize: size,
        lineHeight: 1.3,
        letterSpacing: 0,
        color,
        whiteSpace: "nowrap",
        ...style,
      }}
    >
      {icon}
      {children}
    </div>
  );
};
