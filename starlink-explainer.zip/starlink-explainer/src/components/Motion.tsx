import React from "react";
import {AbsoluteFill, interpolate, spring} from "remotion";
import {theme} from "../theme";
import {useT} from "./useT";

type SpringCfg = {damping: number; stiffness: number; mass: number};

/** Spring progress 0→1 starting at `delay` frames. */
export const useSpring = (delay = 0, cfg: SpringCfg = theme.spring.smooth) => {
  const {frame, fps} = useT();
  return spring({frame: frame - delay, fps, config: cfg});
};

/** Entrance: opacity + translate + scale (+ optional blur). Never a lone fade. */
export const Entrance: React.FC<{
  delay?: number;
  x?: number;
  y?: number;
  from?: number;
  blur?: number;
  cfg?: SpringCfg;
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({delay = 0, x = 0, y = 40, from = 0.94, blur = 0, cfg = theme.spring.smooth, style, children}) => {
  const p = useSpring(delay, cfg);
  const o = Math.min(1, Math.max(0, p * 1.4));
  return (
    <div
      style={{
        opacity: o,
        transform: `translate(${interpolate(p, [0, 1], [x, 0])}px, ${interpolate(p, [0, 1], [y, 0])}px) scale(${interpolate(p, [0, 1], [from, 1])})`,
        filter: blur ? `blur(${Math.max(0, (1 - p) * blur)}px)` : undefined,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** Idle breathing: gentle float + scale for elements on screen > 2s. */
export const Float: React.FC<{amp?: number; period?: number; phase?: number; style?: React.CSSProperties; children: React.ReactNode}> = ({
  amp = 6,
  period = 38,
  phase = 0,
  style,
  children,
}) => {
  const {frame} = useT();
  return (
    <div
      style={{
        transform: `translateY(${Math.sin(frame / period + phase) * amp}px) scale(${1 + Math.sin(frame / (period * 0.7) + phase) * 0.008})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** Scene wrapper: everything exits quickly (faster than entrances) at the end of the scene. */
export const SceneShell: React.FC<{last?: boolean; children: React.ReactNode}> = ({last, children}) => {
  const {frame, s, dur} = useT();
  const ex = last
    ? 0
    : interpolate(frame, [dur - s(theme.dur.exit), dur - 1], [0, 1], {
        easing: theme.ease.in,
        extrapolateLeft: "clamp",
        extrapolateRight: "clamp",
      });
  return (
    <AbsoluteFill
      style={{
        opacity: 1 - ex,
        transform: `translateY(${-30 * ex}px) scale(${1 + 0.03 * ex})`,
        filter: ex > 0 ? `blur(${ex * 6}px)` : undefined,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

/** Progress 0→1 over `seconds` after `delay` frames, eased (never linear). */
export const useProgress = (delay: number, seconds: number, easing = theme.ease.out) => {
  const {frame, s} = useT();
  return interpolate(frame, [delay, delay + s(seconds)], [0, 1], {
    easing,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
};
