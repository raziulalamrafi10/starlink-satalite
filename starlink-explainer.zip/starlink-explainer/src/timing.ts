// All timing is derived from the SRT. Nothing is placed by hand.
import {FPS} from "./config";
import {SRT} from "./data/script";

export type Cue = {
  n: number;
  startSec: number;
  endSec: number;
  startF: number;
  endF: number;
  lines: string[];
};

const toSec = (t: string) => {
  const m = t.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  if (!m) throw new Error("Bad SRT time: " + t);
  return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / 1000;
};

export const parseSrt = (raw: string): Cue[] =>
  raw
    .replace(/\r/g, "")
    .trim()
    .split(/\n\s*\n/)
    .map((block) => {
      const rows = block.split("\n");
      const n = parseInt(rows[0], 10);
      const [a, b] = rows[1].split("-->");
      const startSec = toSec(a);
      const endSec = toSec(b);
      return {
        n,
        startSec,
        endSec,
        startF: Math.round(startSec * FPS),
        endF: Math.round(endSec * FPS),
        lines: rows.slice(2).filter(Boolean),
      };
    });

export const CUES = parseSrt(SRT);
export const TOTAL_FRAMES = Math.ceil(CUES[CUES.length - 1].endSec * FPS);

// Visuals arrive a little before the spoken words (0.17s ≈ 5 frames @30fps).
export const LEAD = Math.round(0.17 * FPS);

// Scenes = groups of cues (scene borders always sit on cue borders).
export const SCENE_CUES: number[][] = [[1], [2], [3], [4], [5], [6]];

export type SceneTiming = {from: number; duration: number; cues: number[]};

export const SCENES: SceneTiming[] = SCENE_CUES.map((group, i) => {
  const first = CUES.find((c) => c.n === group[0])!;
  const from = i === 0 ? 0 : Math.max(0, first.startF - LEAD);
  const nextFirst = SCENE_CUES[i + 1] ? CUES.find((c) => c.n === SCENE_CUES[i + 1][0])! : null;
  const end = nextFirst ? Math.max(0, nextFirst.startF - LEAD) : TOTAL_FRAMES;
  return {from, duration: end - from, cues: group};
});

const cueOf = (n: number) => CUES.find((c) => c.n === n)!;
const sceneOfCue = (n: number) => SCENES.find((s) => s.cues.includes(n))!;

const compact = (s: string) => s.replace(/\s+/g, "");

/** Scene-local start frame of a cue (with visual lead). */
export const cueStart = (n: number, lead = LEAD) =>
  Math.max(0, cueOf(n).startF - sceneOfCue(n).from - lead);

export const cueDur = (n: number) => cueOf(n).endF - cueOf(n).startF;

/** Scene-local frame where line `li` of cue `n` starts (proportional to text length). */
export const lineStart = (n: number, li: number, lead = LEAD) => {
  const c = cueOf(n);
  const total = compact(c.lines.join("")).length;
  const before = compact(c.lines.slice(0, li).join("")).length;
  const f = c.startF + Math.round((c.endF - c.startF) * (before / total));
  return Math.max(0, f - sceneOfCue(n).from - lead);
};

/** Scene-local frame where a given word of cue `n` is spoken (proportional estimate). */
export const wordStart = (n: number, word: string, lead = LEAD) => {
  const c = cueOf(n);
  const all = c.lines.join(" ");
  const idx = all.indexOf(word);
  if (idx < 0) throw new Error(`Word "${word}" not found in cue ${n}`);
  const total = compact(all).length;
  const before = compact(all.slice(0, idx)).length;
  const f = c.startF + Math.round((c.endF - c.startF) * (before / total));
  return Math.max(0, f - sceneOfCue(n).from - lead);
};

/** Item i of k named items in one cue → equally spaced across the cue (scene-local). */
export const spread = (n: number, k: number, i: number, lead = LEAD) =>
  Math.max(0, cueOf(n).startF + Math.round((cueDur(n) * i) / k) - sceneOfCue(n).from - lead);

/** Scene-local end of a cue. */
export const cueEnd = (n: number) => cueOf(n).endF - sceneOfCue(n).from;
