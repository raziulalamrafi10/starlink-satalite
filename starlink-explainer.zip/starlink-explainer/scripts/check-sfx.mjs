// Verifies each WAV: duration, peak level, clipping.
import fs from "node:fs";
import path from "node:path";
import {fileURLToPath} from "node:url";
const dir = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "public", "sfx");
for (const f of fs.readdirSync(dir).filter((n) => n.endsWith(".wav")).sort()) {
  const b = fs.readFileSync(path.join(dir, f));
  const n = (b.length - 44) / 2;
  let peak = 0, clip = 0, sum = 0;
  for (let i = 0; i < n; i++) {
    const v = b.readInt16LE(44 + i * 2) / 32768;
    peak = Math.max(peak, Math.abs(v));
    if (Math.abs(v) >= 0.999) clip++;
    sum += v * v;
  }
  const dur = n / 44100;
  const db = 20 * Math.log10(peak);
  const rms = 20 * Math.log10(Math.sqrt(sum / n));
  console.log(f.padEnd(18), "dur", dur.toFixed(2) + "s", "peak", peak.toFixed(2), `(${db.toFixed(1)} dBFS)`, "rms", rms.toFixed(1) + " dBFS", "clip", clip);
}
