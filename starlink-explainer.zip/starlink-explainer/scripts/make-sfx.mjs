// Deterministic SFX synthesizer: no downloads, no dependencies.
// Output: public/sfx/*.wav  (16-bit mono, 44.1kHz)
// Usage:  node scripts/make-sfx.mjs
import fs from "node:fs";
import path from "node:path";
import {fileURLToPath} from "node:url";

const SR = 44100;
const OUT = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "public", "sfx");
fs.mkdirSync(OUT, {recursive: true});

// ---------- tiny seeded RNG so every run is identical ----------
let seed = 1234567;
const rnd = () => {
  seed = (seed * 1664525 + 1013904223) >>> 0;
  return seed / 4294967296;
};
const noise = () => rnd() * 2 - 1;

const buf = (sec) => new Float32Array(Math.round(sec * SR));
const TAU = Math.PI * 2;

// ---------- filters ----------
const lowpass = (x, fc) => {
  const a = 1 - Math.exp((-TAU * fc) / SR);
  const y = new Float32Array(x.length);
  let s = 0;
  for (let i = 0; i < x.length; i++) {
    s += a * (x[i] - s);
    y[i] = s;
  }
  return y;
};
const highpass = (x, fc) => {
  const lp = lowpass(x, fc);
  const y = new Float32Array(x.length);
  for (let i = 0; i < x.length; i++) y[i] = x[i] - lp[i];
  return y;
};
// state-variable band-pass with time-varying centre frequency
const bandpassSweep = (x, fcAt, q) => {
  const y = new Float32Array(x.length);
  let low = 0,
    band = 0;
  for (let i = 0; i < x.length; i++) {
    const fc = fcAt(i / x.length);
    const f = 2 * Math.sin((Math.PI * fc) / SR);
    low += f * band;
    const high = x[i] - low - band / q;
    band += f * high;
    y[i] = band;
  }
  return y;
};

// ---------- tiny reverb (3 short feedback combs, low mix) ----------
const reverb = (x, mix = 0.12) => {
  const tail = Math.round(0.06 * SR);
  const y = new Float32Array(x.length + tail);
  y.set(x);
  const combs = [
    {d: Math.round(0.0297 * SR), g: 0.28},
    {d: Math.round(0.0371 * SR), g: 0.24},
    {d: Math.round(0.0437 * SR), g: 0.2},
  ];
  const wet = new Float32Array(y.length);
  for (const {d, g} of combs) {
    const c = new Float32Array(y.length);
    for (let i = 0; i < y.length; i++) {
      const dry = i < x.length ? x[i] : 0;
      c[i] = dry + (i >= d ? c[i - d] * g : 0);
    }
    for (let i = 0; i < y.length; i++) wet[i] += c[i] / combs.length;
  }
  const lpWet = lowpass(wet, 2800);
  for (let i = 0; i < y.length; i++) y[i] = x[i < x.length ? i : 0] * (i < x.length ? 1 : 0) + lpWet[i] * mix;
  return y;
};

// ---------- finishing: fade tail to 0, normalise peak ----------
const finish = (x, {peak = 0.8, fadeOut = 0.02} = {}) => {
  const y = Float32Array.from(x);
  const n = Math.round(fadeOut * SR);
  for (let i = 0; i < n; i++) y[y.length - 1 - i] *= i / n;
  let m = 0;
  for (const v of y) m = Math.max(m, Math.abs(v));
  const k = m > 0 ? peak / m : 1;
  for (let i = 0; i < y.length; i++) y[i] *= k;
  return y;
};

const writeWav = (name, x) => {
  const data = Buffer.alloc(x.length * 2);
  for (let i = 0; i < x.length; i++) {
    const v = Math.max(-1, Math.min(1, x[i]));
    data.writeInt16LE(Math.round(v * 32767), i * 2);
  }
  const h = Buffer.alloc(44);
  h.write("RIFF", 0);
  h.writeUInt32LE(36 + data.length, 4);
  h.write("WAVE", 8);
  h.write("fmt ", 12);
  h.writeUInt32LE(16, 16);
  h.writeUInt16LE(1, 20);
  h.writeUInt16LE(1, 22);
  h.writeUInt32LE(SR, 24);
  h.writeUInt32LE(SR * 2, 28);
  h.writeUInt16LE(2, 32);
  h.writeUInt16LE(16, 34);
  h.write("data", 36);
  h.writeUInt32LE(data.length, 40);
  fs.writeFileSync(path.join(OUT, name), Buffer.concat([h, data]));
};

// ================= SOUNDS =================

// pop: sine with fast downward pitch + short envelope
const pop = () => {
  const x = buf(0.2);
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const f = 190 + 420 * Math.exp(-t / 0.028);
    ph += (TAU * f) / SR;
    const env = Math.min(1, t / 0.004) * Math.exp(-t / 0.05);
    x[i] = Math.sin(ph) * env + Math.sin(ph * 2) * 0.12 * env;
  }
  return finish(reverb(lowpass(x, 3600), 0.1), {peak: 0.8});
};

// click: high-passed noise burst + tiny tick, crisp but soft
const click = () => {
  const x = buf(0.08);
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    ph += (TAU * 2100) / SR;
    const env = Math.min(1, t / 0.0012) * Math.exp(-t / 0.014);
    x[i] = (noise() * 0.8 + Math.sin(ph) * 0.35) * env;
  }
  return finish(reverb(lowpass(highpass(x, 1700), 7000), 0.06), {peak: 0.8});
};

// whoosh (transition): band-pass noise sweep, fade in/out
const whoosh = (dur, f0, f1, q, peakShape = 0.45) => {
  const x = buf(dur);
  for (let i = 0; i < x.length; i++) x[i] = noise();
  const y = bandpassSweep(x, (p) => f0 * Math.pow(f1 / f0, p), q);
  for (let i = 0; i < y.length; i++) {
    const p = i / y.length;
    const up = Math.pow(Math.min(1, p / peakShape), 2);
    const down = Math.pow(Math.min(1, (1 - p) / (1 - peakShape)), 1.6);
    y[i] *= up * down;
  }
  return finish(reverb(lowpass(y, 4200), 0.1), {peak: 0.8, fadeOut: 0.04});
};

// chime/pluck: sine + soft overtones, short decay
const chime = () => {
  const x = buf(0.4);
  const parts = [
    [1, 1.0, 0.16],
    [2.0, 0.32, 0.1],
    [3.01, 0.12, 0.07],
    [4.2, 0.05, 0.05],
  ];
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    let v = 0;
    for (const [m, a, tau] of parts) v += Math.sin(TAU * 880 * m * t) * a * Math.exp(-t / tau);
    x[i] = v * Math.min(1, t / 0.006);
  }
  return finish(reverb(lowpass(x, 5200), 0.14), {peak: 0.8, fadeOut: 0.06});
};

// thud: very soft low sine with pitch drop (restrained hook accent)
const thud = () => {
  const x = buf(0.28);
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const f = 52 + 70 * Math.exp(-t / 0.05);
    ph += (TAU * f) / SR;
    x[i] = Math.sin(ph) * Math.min(1, t / 0.006) * Math.exp(-t / 0.09);
  }
  return finish(lowpass(x, 420), {peak: 0.8, fadeOut: 0.05});
};

writeWav("pop.wav", pop());
writeWav("click.wav", click());
writeWav("whoosh.wav", whoosh(0.66, 260, 3200, 1.6, 0.5));
writeWav("whoosh-soft.wav", whoosh(0.4, 420, 1900, 1.2, 0.45));
writeWav("chime.wav", chime());
writeWav("thud.wav", thud());
console.log("SFX written to", OUT);
